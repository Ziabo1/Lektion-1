# draw
This is the base file for drawing a house with pygame. Clone my repository and go crazy!
